#pragma once

namespace Il2CppBridge {
    bool IsRuntimeReady();
    void* GetExport(const char* name);
    const char* GetStatus();
}
