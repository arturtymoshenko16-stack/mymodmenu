#include "Il2CppBridge.h"
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <mutex>
#include <cstring>

#define IL2CPP_LOG_TAG "GkIL2CPP"
#define IL2CPP_LOGI(...) __android_log_print(ANDROID_LOG_INFO, IL2CPP_LOG_TAG, __VA_ARGS__)

namespace {
    std::mutex g_mutex;
    void* g_handle = nullptr;
    bool g_ready = false;
    const char* g_status = "Waiting for libil2cpp.so";

    bool module_loaded() {
        struct Search { bool found = false; } search;
        dl_iterate_phdr([](struct dl_phdr_info* info, size_t, void* data) -> int {
            auto* s = static_cast<Search*>(data);
            if (info && info->dlpi_name && std::strstr(info->dlpi_name, "libil2cpp.so")) {
                s->found = true;
                return 1;
            }
            return 0;
        }, &search);
        return search.found;
    }
}

namespace Il2CppBridge {
    bool IsRuntimeReady() {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (g_ready) return true;
        if (!module_loaded()) {
            g_status = "Waiting for libil2cpp.so";
            return false;
        }
        // RTLD_NOLOAD avoids loading the game runtime ourselves.
        g_handle = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
        if (!g_handle) {
            g_status = "libil2cpp.so found; exports not yet available";
            return false;
        }
        void* domainGet = dlsym(g_handle, "il2cpp_domain_get");
        void* threadAttach = dlsym(g_handle, "il2cpp_thread_attach");
        if (!domainGet || !threadAttach) {
            g_status = "Runtime loaded; required public exports unavailable";
            return false;
        }
        g_ready = true;
        g_status = "IL2CPP runtime detected; game-specific methods not configured";
        IL2CPP_LOGI("%s", g_status);
        return true;
    }

    void* GetExport(const char* name) {
        if (!name || !IsRuntimeReady()) return nullptr;
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_handle ? dlsym(g_handle, name) : nullptr;
    }

    const char* GetStatus() {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_status;
    }
}
